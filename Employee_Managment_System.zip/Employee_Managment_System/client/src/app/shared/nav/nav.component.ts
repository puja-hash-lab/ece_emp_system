import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/shared.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  constructor(private service: SharedService) { }

  currentUser: object = null;

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem("currentUser"));
  }

  logoutClick(){
    this.service.logout();
  }

}
