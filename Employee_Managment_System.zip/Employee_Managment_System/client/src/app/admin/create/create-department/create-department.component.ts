import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-department',
  templateUrl: './create-department.component.html',
  styleUrls: ['./create-department.component.css']
})
export class CreateDepartmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
