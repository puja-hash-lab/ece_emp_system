import { Component, OnInit } from '@angular/core';
import { User } from './user';
@Component({
  selector: 'app-login',
  template: `
  <img src="../images/signup.png">
`,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  userModel = new User('Mainak','mainak@2000');

  onsubmit(){
    console.log(this.userModel)
  }

}
